package com.esame.EsameProgOgg.controller;

import java.util.ArrayList;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.esame.EsameProgOgg.database.DatabaseClass;
import com.esame.EsameProgOgg.model.Metadati;
import com.esame.EsameProgOgg.model.Post;


	@RestController

	public class ControllerPost {
		
		@RequestMapping(value = "metadata", method=RequestMethod.GET)
		public ArrayList<Metadati> getArrayMetadati(){
			
			return DatabaseClass.getArrayMetadati();
		}
		
		@RequestMapping(value="post", method=RequestMethod.GET)
		public ArrayList<Post> getDataWithGet() {
			
			return DatabaseClass.getPost();
		}
}

