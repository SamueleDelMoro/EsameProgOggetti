package com.esame.EsameProgOgg.model;

public class Post {
		private int id;
		private String descrizione;
		public Post(int id, String descrizione) {
			super();
			this.id = id;
			this.descrizione = descrizione;
		}
		/**
		 * @return the id
		 */
		public int getId() {
			return id;
		}
		/**
		 * @param id the id to set
		 */
		public void setId(int id) {
			this.id = id;
		}
		/**
		 * @return the descrizione
		 */
		public String getDescrizione() {
			return descrizione;
		}
		/**
		 * @param descrizione the descrizione to set
		 */
		public void setDescrizione(String descrizione) {
			this.descrizione = descrizione;
		}
		
}
