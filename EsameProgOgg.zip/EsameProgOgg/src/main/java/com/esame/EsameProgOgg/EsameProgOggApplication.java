package com.esame.EsameProgOgg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsameProgOggApplication {

	public static void main(String[] args) {
		SpringApplication.run(EsameProgOggApplication.class, args);
	}

}
