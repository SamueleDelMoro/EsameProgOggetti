package com.esame.EsameProgOgg.model;

public class Like {

}
