package com.esame.EsameProgOgg.others;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.fasterxml.jackson.annotation.JsonIgnore;




public class Downloader {
	public JSONObject getJSONbyURL(String url) throws IOException, ParseException {
		String totdata = "";
		String lines ="";

		try (InputStream imput = new URL(url).openStream()) {
			BufferedReader buffer = new BufferedReader(new InputStreamReader(imput));
			while ((lines = buffer.readLine()) != null) {
				totdata += lines;
			}

			JSONParser parser = new JSONParser();
			Object obj = parser.parse(totdata);

			JSONObject jsonObject = (JSONObject) obj;
			return jsonObject;
		}

	}

	@JsonIgnore
	public String getURL(String id) {
		String url = "https://graph.facebook.com/" + id
				+ "?fields=media_url&acces_token=EAASW9qhdp8QBAFLSZCDiBfjqUKFIC0dlLtiKRt46bZCqbB2zdWnk2YYGvUDxo3koNGVz8wkWyagUZChs6ZCN5mH5oV9tN6b4QXKmrLTorLl1V7MTU0r99kWDahIQyMZBfwJyzz7DpZBeZA4EdoJiTGGNnOB4ebZBQpp7afnuIzZBj8ZA4bOBZAP0YhL0Pi26rlj72W5va3v0RJ4nwZDZD";

		try {
			JSONObject Post = getJSONbyURL(url);
			url = (String) Post.get("media_url");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return url;
	}

	
}
	

