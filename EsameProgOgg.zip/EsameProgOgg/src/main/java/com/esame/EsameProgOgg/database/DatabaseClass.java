package com.esame.EsameProgOgg.database;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.ParseException;

import com.esame.EsameProgOgg.model.Post;

import com.esame.EsameProgOgg.model.Metadati;
public class DatabaseClass {
	private static ArrayList<Post> post= new ArrayList<Post>();
	private static ArrayList<Metadati> metadati= new ArrayList<Metadati>();
	
	public static ArrayList<Post> getPost(){
		return post;
	}
	public static ArrayList<Metadati> getArrayMetadati(){
		metadati.add(new Metadati("id", "Id post", "Integer"));
		metadati.add(new Metadati("descrizione", "Descrizione del post", "String"));
		return metadati;
	}
public static void downloadCsv(String url) {
		
		try {
			
			URLConnection openConnection = new URL(url).openConnection();
			openConnection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
			InputStream in = openConnection.getInputStream();
			
			String data = "";
			String line = "";
			try {
				InputStreamReader inR = new InputStreamReader( in );
				BufferedReader buf = new BufferedReader( inR );
				  
				while ( ( line = buf.readLine() ) != null ) {
					data+= line;
				}
			} catch (IOException e) {
				System.out.println(e.getClass().getCanonicalName()
				+"Errore in com.example.demo.service.DatabaseClass.java: Operazione di I/O interrotte");	
			} finally {
				in.close();
			}
			 
			JSONObject obj = (JSONObject) JSONValue.parseWithException(data); 
			JSONObject objI = (JSONObject) (obj.get("result"));
			JSONArray objA = (JSONArray) (objI.get("resources"));
			
			for(Object o: objA){
				if ( o instanceof JSONObject ) {
			    	JSONObject o1 = (JSONObject)o; 
			    	String name = (String)o1.get("name");
			    	String urlD = (String)o1.get("url");
			    	if(name.equals("Dati anno 2016")) {
			        	download(urlD, "configFile/dataset.csv");
		        	}
			 	}
			}
			
		} catch(ParseException e) {
			System.out.println(e.getClass().getCanonicalName()
				+": Errore in in com.example.demo.service.DatabaseClass.java: "
				+ "Errore nel parsing String - JsonObject");
		} catch (IOException e) {
			System.out.println(e.getClass().getCanonicalName()
				+": Errore in in com.example.demo.service.DatabaseClass.java: "
				+ "Controlla la validità dell URL o Verifica la tua connessione internet");
		}
	}
	
	/**
	 * Effettua il download del dataset, lo copia nella cartella configFile
	 * e ed effettua il parsing, inizzializzando l ArrayList records
	 * @param url che contiene il dataset
	 * @param fileName contiene il nome del file da copiare in configFile
	 */
	
	public static void download(String url, String fileName){
		try (InputStream in = URI.create(url).toURL().openStream()) {
			Files.copy(in, Paths.get(fileName), StandardCopyOption.REPLACE_EXISTING);
			
		} catch ( Exception e) {
			//errore in scrittura
			System.out.println(e.getClass().getCanonicalName()
					+": Errore in in com.example.demo.service.DatabaseClass.java: "
					+ "Errore nella copia del File nella cartella configFile");
		}
	}
	
}
